CASA BLOOM FREE WEBSITE

Files:
- index.html — the complete website.

The WhatsApp buttons use the number supplied in the chat.
Products can be added later by editing the Shop section.

FREE HOSTING:
You can publish this with GitHub Pages or Cloudflare Pages.
